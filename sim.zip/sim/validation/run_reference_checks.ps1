param(
	[string]$GodotExe = "C:\Users\dangp\Desktop\Godot_v4.6.2-stable_win64_console.exe",
	[string]$ProjectPath = "",
	[string]$PythonExe = "python",
	[int]$TimeoutSeconds = 300,
	[switch]$SkipCaseRuns
)

$ErrorActionPreference = "Stop"

if (-not $ProjectPath) {
	$ProjectPath = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
} else {
	$ProjectPath = (Resolve-Path $ProjectPath).Path
}

$runCaseScript = Join-Path $PSScriptRoot "run_case.ps1"
if (-not (Test-Path $runCaseScript)) {
	throw "No se encontro el runner individual: $runCaseScript"
}

$referenceCheckScript = Join-Path $ProjectPath "scripts\simulation\validate_reference_cases.py"
if (-not (Test-Path $referenceCheckScript)) {
	throw "No se encontro el comparador de referencias: $referenceCheckScript"
}

$cases = @(
	"cfast_r0_window_360",
	"ghanekar_bedroom_hallway"
)

Write-Host "[Reference Suite] Inicio de validacion contra referencias externas"
Write-Host ("[Reference Suite] Proyecto: {0}" -f $ProjectPath)
Write-Host ("[Reference Suite] Timeout por caso: {0}s" -f $TimeoutSeconds)

if (-not $SkipCaseRuns) {
	foreach ($caseName in $cases) {
		& $runCaseScript -CaseName $caseName -GodotExe $GodotExe -ProjectPath $ProjectPath -TimeoutSeconds $TimeoutSeconds
	}
} else {
	Write-Host "[Reference Suite] Omitiendo ejecucion de casos; se reutilizan reportes existentes"
}

Write-Host "[Reference Suite] Comparando salidas con NIST CFAST y Ghanekar"
& $PythonExe $referenceCheckScript
$exitCode = $LASTEXITCODE
if ($exitCode -ne 0) {
	throw "El comparador de referencias fallo con exit code $exitCode"
}

Write-Host "[Reference Suite] Resultado final: PASS"
