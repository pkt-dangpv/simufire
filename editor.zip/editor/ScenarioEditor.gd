extends Node2D
class_name ScenarioEditor

enum Tool {
	SELECT,
	ROOM,
	DOOR,
	WINDOW,
	OBJECT,
	IGNITION,
	DELETE
}

const PIXELS_PER_METER: float = 64.0
const GRID_M: float = 0.25
const OUTSIDE_ID: int = -1
const DEFAULT_SAVE_PATH: String = "user://editor_scenario.json"
const RUNTIME_EXPORT_PATH: String = "user://last_editor_runtime_template.json"
const SCENARIOS_RES_PATH: String = "res://scenarios"
const MAIN_SCENE_PATH: String = "res://scenes/SimulationScene.tscn"
const MAIN_MENU_PATH: String = "res://scenes/MainMenu.tscn"
const EditorGridScript = preload("res://editor/EditorGrid.gd")
const ObjectLibraryScript = preload("res://editor/ObjectLibrary.gd")
const Serializer = preload("res://editor/ScenarioSerializer.gd")

var editor_data: Dictionary = {}
var current_tool: int = Tool.SELECT

var selected_room_id: int = -1
var selected_opening_index: int = -1
var selected_object_room_id: int = -1
var selected_object_index: int = -1

var is_dragging_room: bool = false
var drag_start_m: Vector2 = Vector2.ZERO
var drag_current_m: Vector2 = Vector2.ZERO
var pending_door_room_id: int = -1

var _ui_root: Control
var _status_label: Label
var _path_edit: LineEdit
var _object_kind_option: OptionButton
var _name_edit: LineEdit
var _kind_edit: LineEdit
var _height_spin: SpinBox
var _fuel_spin: SpinBox
var _hrr_spin: SpinBox
var _tool_buttons: Dictionary = {}
var _scenario_option: OptionButton
var _scenario_paths: Array[String] = []

var _room_fill: Color = Color(0.14, 0.18, 0.21, 0.62)
var _room_selected_fill: Color = Color(0.17, 0.29, 0.36, 0.70)
var _room_outline: Color = Color(0.74, 0.82, 0.88, 0.92)
var _door_color: Color = Color(0.35, 0.92, 0.58, 0.95)
var _window_color: Color = Color(0.25, 0.72, 1.0, 0.95)
var _object_color: Color = Color(0.95, 0.55, 0.22, 0.88)
var _object_selected_color: Color = Color(1.0, 0.78, 0.30, 0.96)
var _ignition_color: Color = Color(1.0, 0.18, 0.08, 0.98)


func _ready() -> void:
	_create_empty_scenario()
	_setup_grid()
	_setup_ui()
	_set_tool(Tool.SELECT)
	queue_redraw()


func _setup_grid() -> void:
	var grid: Node2D = get_node_or_null("EditorGrid") as Node2D
	if grid == null:
		grid = EditorGridScript.new()
		grid.name = "EditorGrid"
		add_child(grid)
		move_child(grid, 0)
	grid.set("pixels_per_meter", PIXELS_PER_METER)
	grid.set("grid_m", GRID_M)


func _create_empty_scenario() -> void:
	editor_data = {
		"version": 1,
		"outside_temp_c": 20.0,
		"outside_o2": 0.209,
		"room_rect_m": {},
		"rooms_data": [],
		"openings_data": []
	}


func _setup_ui() -> void:
	var canvas: CanvasLayer = get_node_or_null("CanvasLayer") as CanvasLayer
	if canvas == null:
		canvas = CanvasLayer.new()
		canvas.name = "CanvasLayer"
		add_child(canvas)

	_ui_root = canvas.get_node_or_null("UI") as Control
	if _ui_root == null:
		_ui_root = Control.new()
		_ui_root.name = "UI"
		canvas.add_child(_ui_root)
	_ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ui_root.mouse_filter = Control.MOUSE_FILTER_PASS

	var panel := PanelContainer.new()
	panel.name = "ToolsPanel"
	panel.position = Vector2(12.0, 12.0)
	panel.custom_minimum_size = Vector2(440.0, 0.0)
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_ui_root.add_child(panel)

	var main := VBoxContainer.new()
	main.add_theme_constant_override("separation", 8)
	panel.add_child(main)

	var toolbar := HBoxContainer.new()
	toolbar.add_theme_constant_override("separation", 4)
	main.add_child(toolbar)
	_add_tool_button(toolbar, "Sel", Tool.SELECT)
	_add_tool_button(toolbar, "Room", Tool.ROOM)
	_add_tool_button(toolbar, "Door", Tool.DOOR)
	_add_tool_button(toolbar, "Window", Tool.WINDOW)
	_add_tool_button(toolbar, "Object", Tool.OBJECT)
	_add_tool_button(toolbar, "Ignite", Tool.IGNITION)
	_add_tool_button(toolbar, "Del", Tool.DELETE)

	var object_row := HBoxContainer.new()
	main.add_child(object_row)
	var object_label := Label.new()
	object_label.text = "Object"
	object_label.custom_minimum_size.x = 72.0
	object_row.add_child(object_label)
	_object_kind_option = OptionButton.new()
	_object_kind_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for kind in ObjectLibraryScript.get_object_kinds():
		_object_kind_option.add_item(kind)
	object_row.add_child(_object_kind_option)

	main.add_child(HSeparator.new())

	var properties_title := Label.new()
	properties_title.text = "Room properties"
	main.add_child(properties_title)

	_name_edit = _add_line_edit(main, "Name")
	_kind_edit = _add_line_edit(main, "Kind")
	_height_spin = _add_spin(main, "Height m", 1.8, 6.0, 0.1)
	_fuel_spin = _add_spin(main, "Fuel MJ", 0.0, 10000.0, 10.0)
	_hrr_spin = _add_spin(main, "Max HRR kW", 0.0, 5000.0, 10.0)

	var apply_button := Button.new()
	apply_button.text = "Apply room"
	apply_button.pressed.connect(_apply_room_properties)
	main.add_child(apply_button)

	main.add_child(HSeparator.new())

	var path_row := HBoxContainer.new()
	main.add_child(path_row)
	_path_edit = LineEdit.new()
	_path_edit.text = DEFAULT_SAVE_PATH
	_path_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	path_row.add_child(_path_edit)

	var file_row := HBoxContainer.new()
	file_row.add_theme_constant_override("separation", 4)
	main.add_child(file_row)
	_add_action_button(file_row, "Save", _save_pressed)
	_add_action_button(file_row, "Load", _load_pressed)
	_add_action_button(file_row, "Export runtime", _export_runtime_pressed)

	main.add_child(HSeparator.new())

	# ---- Panel de escenarios predefinidos ----
	var scenarios_title := Label.new()
	scenarios_title.text = "Scenarios"
	main.add_child(scenarios_title)

	var scenarios_row := HBoxContainer.new()
	scenarios_row.add_theme_constant_override("separation", 4)
	main.add_child(scenarios_row)
	_scenario_option = OptionButton.new()
	_scenario_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scenarios_row.add_child(_scenario_option)
	_add_action_button(scenarios_row, "Load", _load_scenario_pressed)

	main.add_child(HSeparator.new())

	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 6)
	main.add_child(action_row)
	var run_button := Button.new()
	run_button.text = "✓ Iniciar simulación"
	run_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	run_button.custom_minimum_size = Vector2(0.0, 36.0)
	run_button.pressed.connect(_run_simulation_pressed)
	action_row.add_child(run_button)
	var cancel_button := Button.new()
	cancel_button.text = "✗ Cancelar"
	cancel_button.custom_minimum_size = Vector2(100.0, 36.0)
	cancel_button.pressed.connect(_cancel_pressed)
	action_row.add_child(cancel_button)

	_scan_scenario_files()

	_status_label = Label.new()
	_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status_label.custom_minimum_size = Vector2(410.0, 0.0)
	main.add_child(_status_label)

	_refresh_property_panel()
	_set_status("Listo. Dibuja habitaciones arrastrando con Room.")


func _add_tool_button(parent: Control, label: String, tool_id: int) -> void:
	var button := Button.new()
	button.text = label
	button.toggle_mode = true
	button.custom_minimum_size = Vector2(50.0, 28.0)
	button.pressed.connect(Callable(self, "_set_tool").bind(tool_id))
	parent.add_child(button)
	_tool_buttons[tool_id] = button


func _add_action_button(parent: Control, label: String, callback: Callable) -> void:
	var button := Button.new()
	button.text = label
	button.pressed.connect(callback)
	parent.add_child(button)


func _add_line_edit(parent: Control, label: String) -> LineEdit:
	var row := HBoxContainer.new()
	parent.add_child(row)
	var row_label := Label.new()
	row_label.text = label
	row_label.custom_minimum_size.x = 96.0
	row.add_child(row_label)
	var edit := LineEdit.new()
	edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(edit)
	return edit


func _add_spin(parent: Control, label: String, min_value: float, max_value: float, step: float) -> SpinBox:
	var row := HBoxContainer.new()
	parent.add_child(row)
	var row_label := Label.new()
	row_label.text = label
	row_label.custom_minimum_size.x = 96.0
	row.add_child(row_label)
	var spin := SpinBox.new()
	spin.min_value = min_value
	spin.max_value = max_value
	spin.step = step
	spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(spin)
	return spin


func _set_tool(tool_id: int) -> void:
	current_tool = tool_id
	pending_door_room_id = -1
	for key in _tool_buttons.keys():
		var button: Button = _tool_buttons[key]
		button.button_pressed = int(key) == current_tool
	_clear_drag()
	_set_status(_tool_hint(current_tool))


func _tool_hint(tool_id: int) -> String:
	match tool_id:
		Tool.SELECT:
			return "Select: selecciona habitaciones, objetos o aperturas."
		Tool.ROOM:
			return "Room: arrastra para crear una estancia."
		Tool.DOOR:
			return "Door: pulsa sobre una pared compartida o selecciona dos estancias adyacentes."
		Tool.WINDOW:
			return "Window: pulsa cerca de una pared exterior."
		Tool.OBJECT:
			return "Object: pulsa dentro de una estancia para colocar el combustible elegido."
		Tool.IGNITION:
			return "Ignite: pulsa un objeto para marcarlo como foco inicial."
		Tool.DELETE:
			return "Delete: elimina objeto, apertura o estancia bajo el cursor."
	return ""


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		if is_dragging_room:
			drag_current_m = _screen_to_m(event.position)
			queue_redraw()
		return

	if not (event is InputEventMouseButton):
		return

	var mouse_event: InputEventMouseButton = event
	if mouse_event.button_index != MOUSE_BUTTON_LEFT:
		return
	if _is_pointer_over_ui():
		return

	var pos_m: Vector2 = _screen_to_m(mouse_event.position)
	if mouse_event.pressed:
		_handle_press(pos_m)
	else:
		_handle_release(pos_m)


func _handle_press(pos_m: Vector2) -> void:
	match current_tool:
		Tool.ROOM:
			is_dragging_room = true
			drag_start_m = pos_m
			drag_current_m = pos_m
		Tool.SELECT:
			_select_at(pos_m)
		Tool.DOOR:
			_create_door_at(pos_m)
		Tool.WINDOW:
			_create_window_at(pos_m)
		Tool.OBJECT:
			_create_object_at(pos_m)
		Tool.IGNITION:
			_mark_ignition_at(pos_m)
		Tool.DELETE:
			_delete_at(pos_m)


func _handle_release(pos_m: Vector2) -> void:
	if current_tool != Tool.ROOM or not is_dragging_room:
		return

	drag_current_m = pos_m
	var rect: Rect2 = _normalized_rect(drag_start_m, drag_current_m)
	_clear_drag()

	if rect.size.x < GRID_M or rect.size.y < GRID_M:
		_set_status("La habitacion es demasiado pequena.")
		queue_redraw()
		return

	var room_id: int = _create_room(rect)
	_select_room(room_id)
	_set_status("Habitacion %d creada." % room_id)
	queue_redraw()


func _is_pointer_over_ui() -> bool:
	var hovered: Control = get_viewport().gui_get_hovered_control()
	return hovered != null and _ui_root != null and _ui_root.is_ancestor_of(hovered)


func _screen_to_m(screen_pos: Vector2) -> Vector2:
	var local_px: Vector2 = get_global_transform_with_canvas().affine_inverse() * screen_pos
	return _snap_m(local_px / PIXELS_PER_METER)


func _m_to_px(pos_m: Vector2) -> Vector2:
	return pos_m * PIXELS_PER_METER


func _rect_to_px(rect_m: Rect2) -> Rect2:
	return Rect2(_m_to_px(rect_m.position), rect_m.size * PIXELS_PER_METER)


func _snap_m(pos_m: Vector2) -> Vector2:
	return Vector2(snappedf(pos_m.x, GRID_M), snappedf(pos_m.y, GRID_M))


func _normalized_rect(a: Vector2, b: Vector2) -> Rect2:
	var pos := Vector2(minf(a.x, b.x), minf(a.y, b.y))
	var size := Vector2(absf(a.x - b.x), absf(a.y - b.y))
	return Rect2(pos, size)


func _clear_drag() -> void:
	is_dragging_room = false
	drag_start_m = Vector2.ZERO
	drag_current_m = Vector2.ZERO


func _create_room(rect: Rect2) -> int:
	var id: int = _next_room_id()
	var rooms: Array = editor_data.get("rooms_data", [])
	var rects: Dictionary = editor_data.get("room_rect_m", {})
	var room := {
		"id": id,
		"name": "Room %d" % id,
		"kind": "generic",
		"height_m": 2.7,
		"fuel_energy_MJ": 0.0,
		"max_hrr_kw": 0.0,
		"fuel_objects": []
	}
	rooms.append(room)
	rects[str(id)] = Serializer.rect_to_data(rect)
	editor_data["rooms_data"] = rooms
	editor_data["room_rect_m"] = rects
	return id


func _next_room_id() -> int:
	var next_id: int = 0
	for room in editor_data.get("rooms_data", []):
		if typeof(room) == TYPE_DICTIONARY:
			next_id = maxi(next_id, int(room.get("id", -1)) + 1)
	return next_id


func _next_object_id() -> String:
	var count: int = 0
	for room in editor_data.get("rooms_data", []):
		if typeof(room) != TYPE_DICTIONARY:
			continue
		count += Array(room.get("fuel_objects", [])).size()
	return "obj_%03d" % (count + 1)


func _select_at(pos_m: Vector2) -> void:
	var hit_obj: Dictionary = _find_object_at(pos_m)
	if not hit_obj.is_empty():
		_select_object(int(hit_obj["room_id"]), int(hit_obj["object_index"]))
		return

	var opening_index: int = _find_opening_at(pos_m)
	if opening_index >= 0:
		_select_opening(opening_index)
		return

	var room_id: int = _find_room_at(pos_m)
	if room_id >= 0:
		_select_room(room_id)
	else:
		_clear_selection()
		_set_status("Sin seleccion.")
	queue_redraw()


func _select_room(room_id: int) -> void:
	selected_room_id = room_id
	selected_opening_index = -1
	selected_object_room_id = -1
	selected_object_index = -1
	_refresh_property_panel()
	_set_status("Seleccionada habitacion %d." % room_id)
	queue_redraw()


func _select_opening(index: int) -> void:
	selected_room_id = -1
	selected_opening_index = index
	selected_object_room_id = -1
	selected_object_index = -1
	_refresh_property_panel()
	var opening: Dictionary = Array(editor_data.get("openings_data", []))[index]
	_set_status("Seleccionada apertura %d (%s)." % [index, String(opening.get("type", "door"))])
	queue_redraw()


func _select_object(room_id: int, object_index: int) -> void:
	selected_room_id = -1
	selected_opening_index = -1
	selected_object_room_id = room_id
	selected_object_index = object_index
	_refresh_property_panel()
	var obj: Dictionary = _get_object(room_id, object_index)
	_set_status("Seleccionado objeto %s." % String(obj.get("name", obj.get("id", ""))))
	queue_redraw()


func _clear_selection() -> void:
	selected_room_id = -1
	selected_opening_index = -1
	selected_object_room_id = -1
	selected_object_index = -1
	_refresh_property_panel()


func _refresh_property_panel() -> void:
	if _name_edit == null:
		return

	var room: Dictionary = _get_room(selected_room_id)
	var has_room: bool = not room.is_empty()
	_name_edit.editable = has_room
	_kind_edit.editable = has_room
	_height_spin.editable = has_room
	_fuel_spin.editable = has_room
	_hrr_spin.editable = has_room

	if has_room:
		_name_edit.text = String(room.get("name", ""))
		_kind_edit.text = String(room.get("kind", "generic"))
		_height_spin.value = float(room.get("height_m", 2.7))
		_fuel_spin.value = float(room.get("fuel_energy_MJ", 0.0))
		_hrr_spin.value = float(room.get("max_hrr_kw", 0.0))
	else:
		_name_edit.text = ""
		_kind_edit.text = ""
		_height_spin.value = 2.7
		_fuel_spin.value = 0.0
		_hrr_spin.value = 0.0


func _apply_room_properties() -> void:
	if selected_room_id < 0:
		_set_status("Selecciona una habitacion antes de aplicar propiedades.")
		return

	var rooms: Array = editor_data.get("rooms_data", [])
	for i in range(rooms.size()):
		if typeof(rooms[i]) != TYPE_DICTIONARY:
			continue
		if int(rooms[i].get("id", -1)) != selected_room_id:
			continue
		var room: Dictionary = rooms[i]
		room["name"] = _name_edit.text.strip_edges()
		room["kind"] = _kind_edit.text.strip_edges()
		room["height_m"] = _height_spin.value
		room["fuel_energy_MJ"] = _fuel_spin.value
		room["max_hrr_kw"] = _hrr_spin.value
		rooms[i] = room
		editor_data["rooms_data"] = rooms
		_set_status("Propiedades de habitacion %d actualizadas." % selected_room_id)
		queue_redraw()
		return


func _get_room(room_id: int) -> Dictionary:
	for room in editor_data.get("rooms_data", []):
		if typeof(room) == TYPE_DICTIONARY and int(room.get("id", -1)) == room_id:
			return room
	return {}


func _get_room_rect(room_id: int) -> Rect2:
	var rects: Dictionary = editor_data.get("room_rect_m", {})
	return Serializer.rect2_from_data(rects.get(str(room_id), Rect2()))


func _get_object(room_id: int, object_index: int) -> Dictionary:
	var room: Dictionary = _get_room(room_id)
	var objects: Array = room.get("fuel_objects", [])
	if object_index < 0 or object_index >= objects.size():
		return {}
	if typeof(objects[object_index]) != TYPE_DICTIONARY:
		return {}
	return objects[object_index]


func _find_room_at(pos_m: Vector2) -> int:
	for room in editor_data.get("rooms_data", []):
		if typeof(room) != TYPE_DICTIONARY:
			continue
		var room_id: int = int(room.get("id", -1))
		if _get_room_rect(room_id).has_point(pos_m):
			return room_id
	return -1


func _find_object_at(pos_m: Vector2) -> Dictionary:
	for room in editor_data.get("rooms_data", []):
		if typeof(room) != TYPE_DICTIONARY:
			continue
		var room_id: int = int(room.get("id", -1))
		var room_rect: Rect2 = _get_room_rect(room_id)
		var objects: Array = room.get("fuel_objects", [])
		for object_index in range(objects.size()):
			if typeof(objects[object_index]) != TYPE_DICTIONARY:
				continue
			var obj: Dictionary = objects[object_index]
			var pos: Vector2 = Serializer.vector2_from_data(obj.get("position_m", Vector2.ZERO))
			var size: Vector2 = Serializer.vector2_from_data(obj.get("size_m", Vector2.ONE))
			var obj_rect := Rect2(room_rect.position + pos, size)
			if obj_rect.has_point(pos_m):
				return {"room_id": room_id, "object_index": object_index}
	return {}


func _find_opening_at(pos_m: Vector2) -> int:
	var openings: Array = editor_data.get("openings_data", [])
	for i in range(openings.size()):
		if typeof(openings[i]) != TYPE_DICTIONARY:
			continue
		var segment: PackedVector2Array = _opening_segment_m(openings[i])
		if segment.size() != 2:
			continue
		if _distance_to_segment(pos_m, segment[0], segment[1]) <= 0.18:
			return i
	return -1


func _create_object_at(pos_m: Vector2) -> void:
	var room_id: int = _find_room_at(pos_m)
	if room_id < 0:
		_set_status("Pulsa dentro de una habitacion para colocar un objeto.")
		return

	var selected: int = _object_kind_option.selected
	var kind: String = _object_kind_option.get_item_text(selected) if selected >= 0 else "sofa"
	var room_rect: Rect2 = _get_room_rect(room_id)
	var obj: Dictionary = ObjectLibraryScript.create_object(kind, _next_object_id(), room_id, Vector2.ZERO)
	var size: Vector2 = Serializer.vector2_from_data(obj.get("size_m", Vector2.ONE))
	var local_pos: Vector2 = pos_m - room_rect.position - size * 0.5
	local_pos.x = clampf(local_pos.x, 0.0, maxf(0.0, room_rect.size.x - size.x))
	local_pos.y = clampf(local_pos.y, 0.0, maxf(0.0, room_rect.size.y - size.y))
	obj["position_m"] = Serializer.vector_to_data(local_pos)
	_add_object_to_room(room_id, obj)
	_select_object(room_id, Array(_get_room(room_id).get("fuel_objects", [])).size() - 1)
	_set_status("Objeto %s colocado en habitacion %d." % [kind, room_id])
	queue_redraw()


func _add_object_to_room(room_id: int, obj: Dictionary) -> void:
	var rooms: Array = editor_data.get("rooms_data", [])
	for i in range(rooms.size()):
		if typeof(rooms[i]) != TYPE_DICTIONARY:
			continue
		if int(rooms[i].get("id", -1)) != room_id:
			continue
		var room: Dictionary = rooms[i]
		var objects: Array = room.get("fuel_objects", [])
		objects.append(obj)
		room["fuel_objects"] = objects
		rooms[i] = room
		editor_data["rooms_data"] = rooms
		return


func _mark_ignition_at(pos_m: Vector2) -> void:
	var hit: Dictionary = _find_object_at(pos_m)
	if hit.is_empty():
		_set_status("Pulsa sobre un objeto combustible para marcar el foco inicial.")
		return

	var target_room_id: int = int(hit["room_id"])
	var target_index: int = int(hit["object_index"])
	var rooms: Array = editor_data.get("rooms_data", [])
	for i in range(rooms.size()):
		if typeof(rooms[i]) != TYPE_DICTIONARY:
			continue
		var room: Dictionary = rooms[i]
		var objects: Array = room.get("fuel_objects", [])
		for j in range(objects.size()):
			if typeof(objects[j]) != TYPE_DICTIONARY:
				continue
			var obj: Dictionary = objects[j]
			obj["is_primary_ignition_source"] = int(room.get("id", -1)) == target_room_id and j == target_index
			objects[j] = obj
		room["fuel_objects"] = objects
		rooms[i] = room
	editor_data["rooms_data"] = rooms
	_select_object(target_room_id, target_index)
	_set_status("Foco inicial marcado.")
	queue_redraw()


func _create_door_at(pos_m: Vector2) -> void:
	var shared: Dictionary = _find_shared_wall_at(pos_m)
	if not shared.is_empty():
		_add_opening(int(shared["a"]), int(shared["b"]), "door", String(shared["wall"]), float(shared["offset_m"]), 0.9, 2.05, 0.0, 1.0)
		_set_status("Puerta creada entre habitaciones %d y %d." % [int(shared["a"]), int(shared["b"])])
		queue_redraw()
		return

	var room_id: int = _find_room_at(pos_m)
	if room_id < 0:
		_set_status("Pulsa una pared compartida o una habitacion.")
		return

	if pending_door_room_id < 0:
		pending_door_room_id = room_id
		_set_status("Primera habitacion %d seleccionada para puerta." % room_id)
		return

	if pending_door_room_id == room_id:
		_set_status("Selecciona una segunda habitacion adyacente.")
		return

	var connection: Dictionary = _shared_wall_between(pending_door_room_id, room_id)
	if connection.is_empty():
		_set_status("Las habitaciones %d y %d no comparten pared." % [pending_door_room_id, room_id])
		pending_door_room_id = -1
		return

	_add_opening(
		pending_door_room_id,
		room_id,
		"door",
		String(connection["wall"]),
		float(connection["offset_m"]),
		0.9,
		2.05,
		0.0,
		1.0
	)
	_set_status("Puerta creada entre habitaciones %d y %d." % [pending_door_room_id, room_id])
	pending_door_room_id = -1
	queue_redraw()


func _create_window_at(pos_m: Vector2) -> void:
	var wall: Dictionary = _find_wall_at(pos_m)
	if wall.is_empty():
		_set_status("Pulsa cerca de una pared para crear una ventana.")
		return

	_add_opening(int(wall["room_id"]), OUTSIDE_ID, "window", String(wall["wall"]), float(wall["offset_m"]), 1.2, 1.1, 0.9, 1.0)
	_set_status("Ventana exterior creada en habitacion %d." % int(wall["room_id"]))
	queue_redraw()


func _add_opening(a: int, b: int, type_str: String, wall: String, offset_m: float, width_m: float, height_m: float, sill_m: float, open_fraction: float) -> void:
	var openings: Array = editor_data.get("openings_data", [])
	openings.append({
		"a": a,
		"b": b,
		"type": type_str,
		"wall": wall,
		"offset_m": offset_m,
		"width_m": width_m,
		"height_m": height_m,
		"sill_m": sill_m,
		"open_fraction": open_fraction
	})
	editor_data["openings_data"] = openings
	selected_opening_index = openings.size() - 1
	selected_room_id = -1
	selected_object_room_id = -1
	selected_object_index = -1


func _delete_at(pos_m: Vector2) -> void:
	var hit_obj: Dictionary = _find_object_at(pos_m)
	if not hit_obj.is_empty():
		_delete_object(int(hit_obj["room_id"]), int(hit_obj["object_index"]))
		return

	var opening_index: int = _find_opening_at(pos_m)
	if opening_index >= 0:
		var openings: Array = editor_data.get("openings_data", [])
		openings.remove_at(opening_index)
		editor_data["openings_data"] = openings
		_clear_selection()
		_set_status("Apertura eliminada.")
		queue_redraw()
		return

	var room_id: int = _find_room_at(pos_m)
	if room_id >= 0:
		_delete_room(room_id)
		return

	_set_status("No hay nada que eliminar bajo el cursor.")


func _delete_object(room_id: int, object_index: int) -> void:
	var rooms: Array = editor_data.get("rooms_data", [])
	for i in range(rooms.size()):
		if typeof(rooms[i]) != TYPE_DICTIONARY:
			continue
		if int(rooms[i].get("id", -1)) != room_id:
			continue
		var room: Dictionary = rooms[i]
		var objects: Array = room.get("fuel_objects", [])
		if object_index >= 0 and object_index < objects.size():
			objects.remove_at(object_index)
			room["fuel_objects"] = objects
			rooms[i] = room
			editor_data["rooms_data"] = rooms
			_clear_selection()
			_set_status("Objeto eliminado.")
			queue_redraw()
		return


func _delete_room(room_id: int) -> void:
	var rooms: Array = editor_data.get("rooms_data", [])
	for i in range(rooms.size() - 1, -1, -1):
		if typeof(rooms[i]) == TYPE_DICTIONARY and int(rooms[i].get("id", -1)) == room_id:
			rooms.remove_at(i)
	editor_data["rooms_data"] = rooms

	var rects: Dictionary = editor_data.get("room_rect_m", {})
	rects.erase(str(room_id))
	editor_data["room_rect_m"] = rects

	var openings: Array = editor_data.get("openings_data", [])
	for i in range(openings.size() - 1, -1, -1):
		if typeof(openings[i]) != TYPE_DICTIONARY:
			continue
		var opening: Dictionary = openings[i]
		if int(opening.get("a", -999)) == room_id or int(opening.get("b", -999)) == room_id:
			openings.remove_at(i)
	editor_data["openings_data"] = openings

	_clear_selection()
	_set_status("Habitacion %d eliminada." % room_id)
	queue_redraw()


func _find_wall_at(pos_m: Vector2) -> Dictionary:
	var best: Dictionary = {}
	var best_distance: float = 0.22
	for room in editor_data.get("rooms_data", []):
		if typeof(room) != TYPE_DICTIONARY:
			continue
		var room_id: int = int(room.get("id", -1))
		var rect: Rect2 = _get_room_rect(room_id)
		for wall in ["top", "bottom", "left", "right"]:
			var segment: PackedVector2Array = _wall_segment(rect, wall, _wall_length(rect, wall) * 0.5, _wall_length(rect, wall))
			var dist: float = _distance_to_segment(pos_m, segment[0], segment[1])
			if dist < best_distance:
				best_distance = dist
				var offset: float = _offset_on_wall(rect, wall, pos_m)
				best = {"room_id": room_id, "wall": wall, "offset_m": offset}
	return best


func _find_shared_wall_at(pos_m: Vector2) -> Dictionary:
	var rooms: Array = editor_data.get("rooms_data", [])
	for i in range(rooms.size()):
		if typeof(rooms[i]) != TYPE_DICTIONARY:
			continue
		var a_id: int = int(rooms[i].get("id", -1))
		for j in range(i + 1, rooms.size()):
			if typeof(rooms[j]) != TYPE_DICTIONARY:
				continue
			var b_id: int = int(rooms[j].get("id", -1))
			var shared: Dictionary = _shared_wall_between(a_id, b_id, pos_m)
			if not shared.is_empty():
				return shared
	return {}


func _shared_wall_between(a_id: int, b_id: int, click_m: Vector2 = Vector2(1.0e20, 1.0e20)) -> Dictionary:
	var a_rect: Rect2 = _get_room_rect(a_id)
	var b_rect: Rect2 = _get_room_rect(b_id)
	var tol: float = 0.05
	var click_filter: bool = click_m.x < 1.0e19 and click_m.y < 1.0e19

	if absf(a_rect.position.x + a_rect.size.x - b_rect.position.x) <= tol:
		return _vertical_shared_wall(a_id, b_id, a_rect, b_rect, "right", click_m, click_filter)
	if absf(b_rect.position.x + b_rect.size.x - a_rect.position.x) <= tol:
		return _vertical_shared_wall(a_id, b_id, a_rect, b_rect, "left", click_m, click_filter)
	if absf(a_rect.position.y + a_rect.size.y - b_rect.position.y) <= tol:
		return _horizontal_shared_wall(a_id, b_id, a_rect, b_rect, "bottom", click_m, click_filter)
	if absf(b_rect.position.y + b_rect.size.y - a_rect.position.y) <= tol:
		return _horizontal_shared_wall(a_id, b_id, a_rect, b_rect, "top", click_m, click_filter)
	return {}


func _vertical_shared_wall(a_id: int, b_id: int, a_rect: Rect2, b_rect: Rect2, wall: String, click_m: Vector2, click_filter: bool) -> Dictionary:
	var start_y: float = maxf(a_rect.position.y, b_rect.position.y)
	var end_y: float = minf(a_rect.position.y + a_rect.size.y, b_rect.position.y + b_rect.size.y)
	if end_y - start_y <= 0.2:
		return {}
	var edge_x: float = a_rect.position.x + a_rect.size.x if wall == "right" else a_rect.position.x
	if click_filter:
		if absf(click_m.x - edge_x) > 0.22 or click_m.y < start_y or click_m.y > end_y:
			return {}
	var center_y: float = clampf(click_m.y if click_filter else (start_y + end_y) * 0.5, start_y, end_y)
	return {
		"a": a_id,
		"b": b_id,
		"wall": wall,
		"offset_m": center_y - a_rect.position.y
	}


func _horizontal_shared_wall(a_id: int, b_id: int, a_rect: Rect2, b_rect: Rect2, wall: String, click_m: Vector2, click_filter: bool) -> Dictionary:
	var start_x: float = maxf(a_rect.position.x, b_rect.position.x)
	var end_x: float = minf(a_rect.position.x + a_rect.size.x, b_rect.position.x + b_rect.size.x)
	if end_x - start_x <= 0.2:
		return {}
	var edge_y: float = a_rect.position.y + a_rect.size.y if wall == "bottom" else a_rect.position.y
	if click_filter:
		if absf(click_m.y - edge_y) > 0.22 or click_m.x < start_x or click_m.x > end_x:
			return {}
	var center_x: float = clampf(click_m.x if click_filter else (start_x + end_x) * 0.5, start_x, end_x)
	return {
		"a": a_id,
		"b": b_id,
		"wall": wall,
		"offset_m": center_x - a_rect.position.x
	}


func _offset_on_wall(rect: Rect2, wall: String, pos_m: Vector2) -> float:
	match wall:
		"top", "bottom":
			return clampf(pos_m.x - rect.position.x, 0.0, rect.size.x)
		"left", "right":
			return clampf(pos_m.y - rect.position.y, 0.0, rect.size.y)
	return 0.0


func _wall_length(rect: Rect2, wall: String) -> float:
	if wall == "top" or wall == "bottom":
		return rect.size.x
	return rect.size.y


func _wall_start_dir(rect: Rect2, wall: String) -> Dictionary:
	match wall:
		"top":
			return {"start": rect.position, "dir": Vector2.RIGHT}
		"bottom":
			return {"start": rect.position + Vector2(0.0, rect.size.y), "dir": Vector2.RIGHT}
		"left":
			return {"start": rect.position, "dir": Vector2.DOWN}
		"right":
			return {"start": rect.position + Vector2(rect.size.x, 0.0), "dir": Vector2.DOWN}
	return {"start": rect.position, "dir": Vector2.RIGHT}


func _wall_segment(rect: Rect2, wall: String, offset_m: float, width_m: float) -> PackedVector2Array:
	var wall_data: Dictionary = _wall_start_dir(rect, wall)
	var start: Vector2 = wall_data["start"]
	var dir: Vector2 = wall_data["dir"]
	var length: float = _wall_length(rect, wall)
	var half_width: float = minf(width_m, length) * 0.5
	var center_offset: float = clampf(offset_m, half_width, maxf(half_width, length - half_width))
	var center: Vector2 = start + dir * center_offset
	return PackedVector2Array([center - dir * half_width, center + dir * half_width])


func _opening_segment_m(opening: Dictionary) -> PackedVector2Array:
	var a_id: int = int(opening.get("a", -1))
	if a_id < 0:
		return PackedVector2Array()
	var rect: Rect2 = _get_room_rect(a_id)
	var wall: String = String(opening.get("wall", ""))
	if wall == "":
		var b_id: int = int(opening.get("b", OUTSIDE_ID))
		var shared: Dictionary = _shared_wall_between(a_id, b_id)
		wall = String(shared.get("wall", "top"))
	var width: float = float(opening.get("width_m", 0.9))
	var offset: float = float(opening.get("offset_m", _wall_length(rect, wall) * 0.5))
	return _wall_segment(rect, wall, offset, width)


func _distance_to_segment(point: Vector2, a: Vector2, b: Vector2) -> float:
	var ab: Vector2 = b - a
	var len_sq: float = ab.length_squared()
	if len_sq <= 0.000001:
		return point.distance_to(a)
	var t: float = clampf((point - a).dot(ab) / len_sq, 0.0, 1.0)
	return point.distance_to(a + ab * t)


func _save_pressed() -> void:
	editor_data = Serializer.normalize_editor_data(editor_data)
	if Serializer.save_scenario(_path_edit.text.strip_edges(), editor_data):
		_set_status("Escenario guardado en %s." % _path_edit.text.strip_edges())
	else:
		_set_status("No se pudo guardar el escenario.")


func _load_pressed() -> void:
	var loaded: Dictionary = Serializer.load_scenario(_path_edit.text.strip_edges())
	if loaded.is_empty():
		_set_status("No se pudo cargar el escenario.")
		return
	editor_data = loaded
	_clear_selection()
	_set_status("Escenario cargado desde %s." % _path_edit.text.strip_edges())
	queue_redraw()


func _export_runtime_pressed() -> void:
	editor_data = Serializer.normalize_editor_data(editor_data)
	var runtime_template: Dictionary = Serializer.to_runtime_template(editor_data)
	var runtime_rooms: Array = runtime_template.get("rooms_data", [])
	if runtime_rooms.is_empty():
		_set_status("No se exporta: el escenario no tiene habitaciones.")
		return
	if Serializer.save_runtime_template(RUNTIME_EXPORT_PATH, editor_data):
		_set_status("Template runtime exportado en %s." % RUNTIME_EXPORT_PATH)
	else:
		_set_status("No se pudo exportar el template runtime.")


func _draw() -> void:
	_draw_rooms()
	_draw_openings()
	_draw_objects()
	if is_dragging_room:
		var rect: Rect2 = _normalized_rect(drag_start_m, drag_current_m)
		var rect_px: Rect2 = _rect_to_px(rect)
		draw_rect(rect_px, Color(0.25, 0.68, 0.95, 0.18), true)
		draw_rect(rect_px, Color(0.55, 0.90, 1.0, 0.85), false, 2.0)


func _draw_rooms() -> void:
	for room in editor_data.get("rooms_data", []):
		if typeof(room) != TYPE_DICTIONARY:
			continue
		var room_id: int = int(room.get("id", -1))
		var rect_px: Rect2 = _rect_to_px(_get_room_rect(room_id))
		var fill: Color = _room_selected_fill if room_id == selected_room_id else _room_fill
		draw_rect(rect_px, fill, true)
		draw_rect(rect_px, _room_outline, false, 2.0)
		if ThemeDB.fallback_font != null:
			draw_string(
				ThemeDB.fallback_font,
				rect_px.position + Vector2(8.0, 18.0),
				String(room.get("name", "Room %d" % room_id)),
				HORIZONTAL_ALIGNMENT_LEFT,
				maxf(40.0, rect_px.size.x - 12.0),
				13,
				Color(0.94, 0.97, 1.0, 0.92)
			)


func _draw_openings() -> void:
	var openings: Array = editor_data.get("openings_data", [])
	for i in range(openings.size()):
		if typeof(openings[i]) != TYPE_DICTIONARY:
			continue
		var opening: Dictionary = openings[i]
		var segment_m: PackedVector2Array = _opening_segment_m(opening)
		if segment_m.size() != 2:
			continue
		var p1: Vector2 = _m_to_px(segment_m[0])
		var p2: Vector2 = _m_to_px(segment_m[1])
		var type_str: String = String(opening.get("type", "door"))
		var color: Color = _window_color if type_str == "window" else _door_color
		if i == selected_opening_index:
			color = Color(1.0, 1.0, 0.45, 1.0)
		draw_line(p1, p2, Color(0.04, 0.06, 0.07, 0.95), 8.0)
		draw_line(p1, p2, color, 4.0)


func _draw_objects() -> void:
	for room in editor_data.get("rooms_data", []):
		if typeof(room) != TYPE_DICTIONARY:
			continue
		var room_id: int = int(room.get("id", -1))
		var room_rect: Rect2 = _get_room_rect(room_id)
		var objects: Array = room.get("fuel_objects", [])
		for object_index in range(objects.size()):
			if typeof(objects[object_index]) != TYPE_DICTIONARY:
				continue
			var obj: Dictionary = objects[object_index]
			var pos: Vector2 = Serializer.vector2_from_data(obj.get("position_m", Vector2.ZERO))
			var size: Vector2 = Serializer.vector2_from_data(obj.get("size_m", Vector2.ONE))
			var obj_rect_px: Rect2 = _rect_to_px(Rect2(room_rect.position + pos, size))
			var selected: bool = room_id == selected_object_room_id and object_index == selected_object_index
			var fill: Color = _object_selected_color if selected else _object_color
			draw_rect(obj_rect_px, fill, true)
			draw_rect(obj_rect_px, Color(0.18, 0.09, 0.04, 0.92), false, 1.5)
			if bool(obj.get("is_primary_ignition_source", false)):
				draw_circle(obj_rect_px.get_center(), 7.0, _ignition_color)
				draw_circle(obj_rect_px.get_center(), 3.5, Color(1.0, 0.94, 0.25, 0.98))
			if ThemeDB.fallback_font != null and obj_rect_px.size.x >= 48.0:
				draw_string(
					ThemeDB.fallback_font,
					obj_rect_px.position + Vector2(4.0, 13.0),
					String(obj.get("kind", "")),
					HORIZONTAL_ALIGNMENT_LEFT,
					obj_rect_px.size.x - 8.0,
					10,
					Color(0.08, 0.05, 0.03, 0.9)
				)


func _set_status(text: String) -> void:
	if _status_label != null:
		_status_label.text = text


func _scan_scenario_files() -> void:
	if _scenario_option == null:
		return
	_scenario_option.clear()
	_scenario_paths.clear()

	var dir := DirAccess.open(SCENARIOS_RES_PATH)
	if dir == null:
		return

	dir.list_dir_begin()
	var file_name: String = dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.ends_with(".json"):
			_scenario_paths.append(SCENARIOS_RES_PATH + "/" + file_name)
			_scenario_option.add_item(file_name)
		file_name = dir.get_next()
	dir.list_dir_end()


func _load_scenario_pressed() -> void:
	if _scenario_option == null:
		return
	var idx: int = _scenario_option.selected
	if idx < 0 or idx >= _scenario_paths.size():
		_set_status("Selecciona un escenario de la lista.")
		return
	var path: String = _scenario_paths[idx]
	var loaded: Dictionary = Serializer.load_scenario(path)
	if loaded.is_empty():
		_set_status("No se pudo cargar: %s" % path)
		return
	editor_data = loaded
	_clear_selection()
	_set_status("Escenario cargado: %s" % path.get_file())
	queue_redraw()


func _run_simulation_pressed() -> void:
	editor_data = Serializer.normalize_editor_data(editor_data)
	var runtime_rooms: Array = editor_data.get("rooms_data", [])
	if runtime_rooms.is_empty():
		_set_status("El escenario no tiene habitaciones. No se puede ejecutar.")
		return
	if not Serializer.save_runtime_template(RUNTIME_EXPORT_PATH, editor_data):
		_set_status("Error al exportar el template runtime.")
		return
	_set_status("Iniciando simulación...")
	get_tree().change_scene_to_file(MAIN_SCENE_PATH)


func _cancel_pressed() -> void:
	get_tree().change_scene_to_file(MAIN_MENU_PATH)
