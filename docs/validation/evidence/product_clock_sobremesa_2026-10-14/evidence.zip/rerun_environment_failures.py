"""Repeat the exact failed node IDs with the required console entry point."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r"C:\Users\dangp\.codex\worktrees\motor-clock-validation\simufire")
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.simulation.run_g3_o2_transport_gate import prepare_environment

nodes = []
for line in (OUT / "pytest_complete.log").read_text(encoding="utf-8").splitlines():
    if line.startswith(("FAILED ", "ERROR ")):
        node = line.split(" ", 1)[1].split(" - ", 1)[0].strip()
        if node not in nodes:
            nodes.append(node)
assert len(nodes) == 64, len(nodes)
(OUT / "pytest_retest_selection.json").write_text(json.dumps({
    "count": len(nodes), "nodes": nodes,
    "changes": ["GODOT_EXE requests the console entry point; the same normal binary is launched by the safe monitor",
                "pypdf dependency available in external target folder",
                "runtime test APPDATA relocated outside the checkout"],
    "production_or_test_sources_changed_for_retest": False,
}, indent=2), encoding="utf-8")
prepare_environment(OUT / "pytest_retest_runtime")
os.environ.update(PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
                  PYTHONPATH=str(OUT / "python_dependencies"),
                  SIMUFIRE_GODOT_TEST_APPDATA=str(OUT / "pytest_retest_runtime" / "appdata"),
                  GODOT_EXE=r"F:\OneDrive\Escritorio\Godot_v4.7.1-stable_win64_console.exe")
print(f"RETEST {len(nodes)} failed node IDs, unchanged source", flush=True)
started = time.monotonic()
with (OUT / "pytest_retest.log").open("w", encoding="utf-8") as log:
    run = subprocess.run([sys.executable, "-X", "utf8", "-m", "pytest", "-q", "-p", "no:cacheprovider",
                          "--basetemp", str(OUT / "pytest_retest_temp"),
                          "--junitxml", str(OUT / "pytest_retest.xml"), *nodes],
                         cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
record = {"exit_code": run.returncode, "wall_s": round(time.monotonic() - started, 3),
          "selected": len(nodes)}
(OUT / "pytest_retest_result.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record), flush=True)
print("\n".join((OUT / "pytest_retest.log").read_text(encoding="utf-8").splitlines()[-12:]), flush=True)
raise SystemExit(run.returncode)
