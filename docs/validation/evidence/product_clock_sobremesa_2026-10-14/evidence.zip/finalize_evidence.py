import hashlib
import importlib.metadata
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(r"C:\Users\dangp\.codex\worktrees\motor-clock-validation\simufire")
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(OUT / "python_dependencies"))
from scripts.verify_product_step_convergence import source_hashes
from scripts import godot_monitored_launch

def read(relative):
    return json.loads((OUT / relative).read_text(encoding="utf-8-sig"))

plan = read("convergence_corrected_fixture/plan.json")
assert source_hashes() == plan["sim_sources_sha256"]
assert not godot_monitored_launch.preexisting_godot_state()
clock = read("clock_corrected/result.json")
assert clock["passed"]
assert hashlib.sha256((ROOT / "Main.gd").read_bytes()).hexdigest() == clock["sources_sha256"]["Main.gd"]
mutations = {name: read(name + "/results.json") for name in ("clock_mutations", "fp_chart_mutations")}
assert all(r["originals_intact"] and r["killed_where_expected"] == 5 for r in mutations.values())
assert read("convergence_cleanup_smoke/result.json")["passed"]
retest = read("pytest_retest_result.json")
assert retest["exit_code"] == 0
suite = ET.parse(OUT / "pytest_retest.xml").getroot().find("testsuite")
assert int(suite.attrib["tests"]) == 64
assert int(suite.attrib["failures"]) == int(suite.attrib["errors"]) == 0
full_text = (OUT / "pytest_complete.log").read_text(encoding="utf-8")
counts = re.findall(r"(\d+) failed, (\d+) passed, (\d+) skipped, (\d+) xfailed, (\d+) errors", full_text)
failed, passed, skipped, xfailed, errors = map(int, counts[-1])
assert failed + errors == 64
passed += 64
assert passed + skipped + xfailed == 5464
assert "ALL PRODUCT CHECKS PASS  (168 tests)" in (OUT / "product.log").read_text(encoding="utf-8")
render = read("render_3d/result.json")
screen = read("convergence_corrected_fixture/result.json")
authored = ["Main.gd", "scripts/verify_product_dispatch.py", "scripts/verify_product_step_convergence.py",
            "scripts/profile_product_render.py", "tests/fixtures/product_dispatch_contract.gd",
            "tests/fixtures/product_step_convergence.gd", "tests/fixtures/product_render_profile.gd",
            "tests/test_fp_live_charts.py", "tests/test_product_render_profile.py",
            "tests/test_product_step_convergence.py"]
summary = {
    "date": "2026-10-14", "machine": read("machine.json"),
    "worktree": str(ROOT), "branch": "codex/motor-clock-validation",
    "base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "evidence_root": str(OUT), "ram_manually_freed": False,
    "python": sys.version, "packages": {p: importlib.metadata.version(p) for p in ("pytest", "jsonschema", "pandas", "numpy", "pypdf")},
    "clock_checks": clock["control"]["checks"], "clock_failures": 0,
    "mutations": {name: {k: r[k] for k in ("declared", "executed", "killed_where_expected", "originals_intact")} for name, r in mutations.items()},
    "product_tests_passed": 168, "existing_reference_guardrails": "346/346; existing reports, not fresh official physical runs",
    "pytest": {"collected": 5464, "passed_across_full_run_and_retest": passed, "skipped": skipped, "xfailed": xfailed,
               "original_environment_failures": failed, "original_environment_errors": errors,
               "retested": 64, "retest_passed": 64,
               "note": "Two passes: complete run then all 64 environment-affected node IDs, unchanged source; not a single all-green run."},
    "physical_sources_unchanged_raw_bytes": True,
    "physical_source_inventory_sha256": hashlib.sha256(json.dumps(plan["sim_sources_sha256"], sort_keys=True).encode()).hexdigest(),
    "step_screen": {"reference_deterministic": screen["reference_deterministic"], "comparisons": screen["comparisons"],
                    "numerical_equivalence_demonstrated": False, "official_physical_acceptance": False},
    "render_3d": {"state": render["state"], "summaries": render["summaries"],
                  "display": {k: render["profile"][k] for k in ("display_server", "rendering_method", "adapter", "window_size", "vsync_mode", "max_fps")}},
    "render_fp": {"accepted": False, "attempts": 2, "reason": "Two GLES texture leak errors at teardown in both attempts; no accepted FPS claim."},
    "cleanup_smoke_passed": True, "ready_to_promote_coarse_physical_step": False,
    "authored_sources_sha256_raw": {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in authored},
}
destination = ROOT / "docs/validation/product_clock_sobremesa_2026-10-14.json"
destination.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
report = ROOT / "docs/validation/PRODUCT_CLOCK_SOBREMESA_2026-10-14.md"
text = report.read_text(encoding="utf-8")
passed_display = f"{passed:,}".replace(",", ".")
text = text.replace("Batería general de Python: ejecución final en curso al redactar esta sección.",
                    f"Batería general de Python: **{passed_display} casos aprobados, {skipped} omitidos y {xfailed} fallos esperados**, combinando la ejecución completa con la repetición de los 64 casos afectados por el entorno. No es una única ejecución completamente verde.")
text = text.replace("Limpieza del guion numérico: comprobación final en curso.",
                    "Limpieza del guion numérico: control nativo de un segundo aprobado; sin generar gráficas ni dashboard al salir.")
text += ("\nLa ejecución completa terminó inicialmente con 5.296 aprobados, 52 fallos y 12 errores. "
         "Los 63 casos nativos reclamaban la ruta de consola para verificar su sustitución segura por el ejecutable normal; "
         "otro caso necesitaba `pypdf`. Se repitieron exactamente los 64 casos: **64/64 aprobados**, "
         "sin modificar código ni aserciones. Las dependencias externas incluyen pypdf 6.20.1. "
         "La selección y los resultados están en `pytest_retest_selection.json`, `pytest_retest_result.json`, "
         "`pytest_retest.xml` y `pytest_retest.log`.\n\n"
         "Resumen verificable y SHA-256 de los archivos editados: `product_clock_sobremesa_2026-10-14.json`. "
         "Los archivos `.gd.uid` creados por la importación de Godot se conservan como archivos generados, fuera del cambio preparado. "
         "Los cambios siguen locales en la copia de pruebas; no se han publicado en Git ni aplicado a la carpeta habitual.\n")
report.write_text(text, encoding="utf-8")
print(json.dumps({"report": str(report), "summary": str(destination), "pytest_passed": passed,
                  "physical_sources_unchanged": True, "no_godot_residue": True}, ensure_ascii=False))
