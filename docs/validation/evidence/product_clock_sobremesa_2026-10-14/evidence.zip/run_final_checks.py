import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r"C:\Users\dangp\.codex\worktrees\motor-clock-validation\simufire")
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.simulation.run_g3_o2_transport_gate import prepare_environment
from scripts import godot_monitored_launch

prepare_environment(OUT / "final_regression_runtime")
os.environ.update(PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
                  PYTHONPATH=str(OUT / "python_dependencies"),
                  GODOT_EXE=r"F:\OneDrive\Escritorio\Godot_v4.7.1-stable_win64.exe")
tasks = [
    ("render_fp_repeat", ["scripts/profile_product_render.py", "--work", str(OUT / "render_fp_repeat"), "--options", str(OUT / "render_options.json"), "--view", "fp"]),
    ("pytest_complete", ["-m", "pytest", "-q", "-p", "no:cacheprovider", "--basetemp", str(OUT / "pytest_temp_complete")]),
]
records = []
for name, args in tasks:
    print(f"START {name}", flush=True)
    started = time.monotonic()
    with (OUT / f"{name}.log").open("w", encoding="utf-8") as log:
        run = subprocess.run([sys.executable, "-X", "utf8", *args], cwd=ROOT,
                             stdout=log, stderr=subprocess.STDOUT)
    records.append({"name": name, "exit_code": run.returncode,
                    "wall_s": round(time.monotonic() - started, 3)})
    (OUT / "final_checks.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
    print(json.dumps(records[-1]), flush=True)
    print("\n".join((OUT / f"{name}.log").read_text(encoding="utf-8").splitlines()[-10:]), flush=True)

print("START convergence_fixture_cleanup_smoke", flush=True)
folder = OUT / "convergence_cleanup_smoke"
folder.mkdir()
run = godot_monitored_launch.run(
    [os.environ["GODOT_EXE"], "--headless", "--path", ROOT,
     "--log-file", folder / "godot.log", "--script", ROOT / "tests/fixtures/product_step_convergence.gd",
     "--", "--step-denominator=60", "--door-schedule=open", "--duration-s=1",
     f"--evidence-out={folder / 'trace.json'}"], timeout_s=60, environment=os.environ.copy())
(folder / "stdout.log").write_text(run.stdout, encoding="utf-8")
(folder / "stderr.log").write_text(run.stderr, encoding="utf-8")
passed = (run.launched and run.returncode == 0 and not run.faults and not run.preexisting
          and not any(t in run.stdout + run.stderr for t in
                      ("SCRIPT ERROR", "Parse Error", "ERROR:", "Generando graficas", "Generando dashboard")))
(folder / "result.json").write_text(json.dumps({"passed": passed, "health": run.health}, indent=2), encoding="utf-8")
print(json.dumps({"cleanup_smoke_passed": passed}), flush=True)
raise SystemExit(0 if passed and all(r["exit_code"] == 0 for r in records) else 1)
