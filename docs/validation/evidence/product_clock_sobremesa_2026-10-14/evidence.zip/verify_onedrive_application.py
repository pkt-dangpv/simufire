import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r"F:\OneDrive\Documentos\GitHub\simufire")
EVIDENCE = Path(__file__).resolve().parent
WORK = EVIDENCE / "onedrive_application"
EXPECTED_HEAD = "060611723b2ae41ddc8f5bafad458908460696c0"
sys.path.insert(0, str(ROOT))
from scripts import godot_monitored_launch
from scripts.simulation.run_g3_o2_transport_gate import prepare_environment

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()

assert git("rev-parse", "HEAD") == EXPECTED_HEAD
assert git("branch", "--show-current") == "main"
for parent in ("1c2389c97c6314de26dafc6661e147bc0800469e", "6633ff78444e8a77c1fcff48f558d04759d07d40", "21c4e8d48c3f16de329e19861edc0e5bd7bba80c"):
    subprocess.run(["git", "merge-base", "--is-ancestor", parent, EXPECTED_HEAD], cwd=ROOT, check=True)
metadata = json.loads((ROOT / "docs/validation/product_clock_sobremesa_2026-10-14.json").read_text(encoding="utf-8"))
for path, expected in metadata["authored_sources_sha256_raw"].items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected, path
prepare_environment(WORK)
os.environ.update(PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
                  GODOT_EXE=r"F:\OneDrive\Escritorio\Godot_v4.7.1-stable_win64.exe",
                  PYTHONPATH=str(EVIDENCE / "python_dependencies"))
print("START monitored import in OneDrive", flush=True)
run = godot_monitored_launch.run([os.environ["GODOT_EXE"], "--headless", "--editor", "--path", ROOT, "--import"],
                                 timeout_s=180, environment=os.environ.copy())
(WORK / "import.stdout.log").write_text(run.stdout, encoding="utf-8")
(WORK / "import.stderr.log").write_text(run.stderr, encoding="utf-8")
(WORK / "import.health.json").write_text(json.dumps(run.health, indent=2), encoding="utf-8")
assert run.launched and run.returncode == 0 and not run.faults and not run.preexisting
assert not any(t in run.stdout + run.stderr for t in ("SCRIPT ERROR", "Parse Error", "ERROR:"))
tasks = [
    ("clock", ["scripts/verify_product_dispatch.py", "--work", str(WORK / "clock")]),
    ("charts", ["scripts/verify_fp_live_charts.py", "--work", str(WORK / "charts")]),
    ("python", ["-m", "pytest", "-q", "-p", "no:cacheprovider", "--basetemp", str(WORK / "pytest_temp"),
                "simufire_ai/tests", "tests/test_fp_live_charts.py", "tests/test_fp_furniture_owner.py",
                "tests/test_furniture_layout_cache.py", "tests/test_product_render_profile.py",
                "tests/test_product_cpu_profile.py", "tests/test_fp_performance_probes.py",
                "tests/test_product_step_convergence.py"]),
]
records = []
for name, args in tasks:
    print("START " + name + " in OneDrive", flush=True)
    started = time.monotonic()
    with (WORK / (name + ".log")).open("w", encoding="utf-8") as log:
        completed = subprocess.run([sys.executable, "-X", "utf8", *args], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    records.append({"name": name, "exit_code": completed.returncode, "wall_s": round(time.monotonic() - started, 3)})
    print(json.dumps(records[-1]), flush=True)
    if completed.returncode:
        print((WORK / (name + ".log")).read_text(encoding="utf-8")[-4000:], flush=True)
        raise RuntimeError("OneDrive check failed: " + name)
assert git("rev-parse", "HEAD") == EXPECTED_HEAD, "OneDrive HEAD changed during verification"
assert git("branch", "--show-current") == "main"
assert not git("diff", "--name-only")
assert not godot_monitored_launch.preexisting_godot_state()
record = {"applied_to": str(ROOT), "branch": "main", "commit": EXPECTED_HEAD,
          "original_local_commits_preserved": True, "origin_main_included": True,
          "tested_clock_source_bytes_identical": True, "checks": records,
          "clock": json.loads((WORK / "clock/result.json").read_text(encoding="utf-8"))["control"],
          "python_summary": (WORK / "python.log").read_text(encoding="utf-8").splitlines()[-1],
          "no_godot_residue": True}
(WORK / "result.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps({"passed": True, "result": str(WORK / "result.json"), "python_summary": record["python_summary"]}), flush=True)
