"""One-off sequential test batch; all native launches use project monitors."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(r"C:\Users\dangp\.codex\worktrees\motor-clock-validation\simufire")
EVIDENCE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.simulation.run_g3_o2_transport_gate import prepare_environment

prepare_environment(EVIDENCE / "regression_runtime")
os.environ.update(PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
                  GODOT_EXE=r"F:\OneDrive\Escritorio\Godot_v4.7.1-stable_win64.exe")
tasks = [
    ("clock_mutations", ["scripts/verify_product_dispatch.py", "--work", str(EVIDENCE / "clock_mutations"), "--mutations"]),
    ("fp_chart_mutations", ["scripts/verify_fp_live_charts.py", "--work", str(EVIDENCE / "fp_chart_mutations"), "--mutations"]),
    ("render_3d", ["scripts/profile_product_render.py", "--work", str(EVIDENCE / "render_3d"), "--options", str(EVIDENCE / "render_options.json"), "--view", "3d"]),
    ("render_fp", ["scripts/profile_product_render.py", "--work", str(EVIDENCE / "render_fp"), "--options", str(EVIDENCE / "render_options.json"), "--view", "fp"]),
    ("pytest", ["-m", "pytest", "-q", "-p", "no:cacheprovider", "--basetemp", str(EVIDENCE / "pytest_temp")]),
    ("product", ["scripts/check_product.py"]),
]
records = []
for name, args in tasks:
    print(f"START {name}", flush=True)
    started = time.monotonic()
    with (EVIDENCE / f"{name}.log").open("w", encoding="utf-8") as log:
        result = subprocess.run([sys.executable, "-X", "utf8", *args], cwd=ROOT,
                                stdout=log, stderr=subprocess.STDOUT)
    records.append({"name": name, "exit_code": result.returncode,
                    "wall_s": round(time.monotonic() - started, 3)})
    (EVIDENCE / "remaining_checks.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
    print(json.dumps(records[-1]), flush=True)
    print("\n".join((EVIDENCE / f"{name}.log").read_text(encoding="utf-8").splitlines()[-8:]), flush=True)
raise SystemExit(0 if all(r["exit_code"] == 0 for r in records) else 1)
