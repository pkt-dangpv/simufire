# Sincronización de SimuFire mediante Git

GitHub y main contienen el commit combinado 8e256c97c55146f3cc13a87a87878df294046c15.
Se han integrado 45 commits remotos y conservado los 20 commits locales.
Los 445 archivos cambiados en remoto y los 249 cambiados localmente se han comprobado contra los respectivos commits.
El único conflicto se resolvió conservando el runner local de 31 pruebas, que incluye la prueba añadida en remoto.
Se conserva la rama codex/backup-sobremesa-before-git-sync-20261011 como referencia del estado previo.

Verificación final: 31/31 scripts deterministas en una copia aislada del commit combinado; enlaces de los 74 documentos modificados elegibles, sin errores.
Los primeros intentos de pruebas se vieron afectados por dependencias ausentes, restricciones de temporales y un cambio de rama durante la ejecución; sus logs se conservan. El resultado final aislado tiene exit code 0.
El comprobador global de documentos también incluye copias locales ignoradas y dos enlaces absolutos preexistentes del addon sky_3d; se comprobó el conjunto de documentos modificados usando el verificador oficial.

Esta copia por Git incluye los archivos y commits publicados. Los archivos ignorados o todavía sin publicar del portátil no se transfieren mediante Git.
La verificación detallada está en VERIFICACION_GIT.json, RESULTADO_TESTS.json y TESTS_SIMUFIRE_AI_AISLADOS.log.
